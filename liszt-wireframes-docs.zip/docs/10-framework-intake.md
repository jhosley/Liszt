# 10. Framework intake: getting the five frameworks into Liszt

**Audience:** the developers building the production tool, and whoever runs the first pin.
**Authority:** `frameworks/baseline-2026.07.yaml` pins the vocabulary, `tools/pin_frameworks.py` performs the pin, and `schema/scenario.schema.json` defines every target field. If this document disagrees with any of them, they win and this document is wrong; file it.

Verified against live upstream sources in August 2026, at baseline 2026.07. Companion artifacts: the [HTML wireframe](wireframes/liszt-framework-intake.html) and the [Word version](wireframes/Liszt-Framework-Intake.docx). The schema side of the system is in [11. The schema behind Liszt](11-schema-wireframes.md).

---

## The one pattern, five times

Every framework follows the same five moves. The sections below are this pattern filled in with each framework's real URLs, formats, and quirks. Nothing is bespoke per framework except the data itself.

1. **Get it.** Download the immutable, versioned artifact from upstream. Never pin a floating "latest" pointer.
2. **Pin it.** Vendor it into `frameworks/pinned/` and record its sha256 in `CHECKSUMS.json`.
3. **Read its schema.** Know the source shape, and where the ID or score lives, before you map anything.
4. **Insert into Liszt.** The ID lands in exactly one `framework_mapping` array. For DeTT&CT, scores land in `telemetry[].dettect`.
5. **Interact.** The validator checks every ID against the pin. Coverage, reports, and migration all read from it.

Three things to hold on to:

- **Two kinds of framework.** Four are ID vocabularies. They hand you identifiers such as `T1611`, `AML.T0105`, `LLM06:2025`, and `ASI10:2026` that land in the `framework_mapping` arrays and, for the two MITRE frameworks, on each `attack_path[]` step. One is a scoring scale: DeTT&CT defines no IDs. It supplies the visibility, detection, and quality scales that fill `telemetry[].dettect`. It is the ruler, not the map.
- **Authoritative vs. editorial.** Exactly one cross-framework link in this whole system is published by a framework owner: the ATLAS `attack-reference` field, which marks an ATLAS technique as adapted from an ATT&CK one (37 of 178 techniques carry it). Only that qualifies as `mapping_confidence: authoritative`. Every other pairing, especially anything touching OWASP, is your judgment: label it `editorial` and explain it in `mapping_notes`. No authoritative OWASP to MITRE crosswalk exists in either direction.
- **The golden rule of pinning.** Pin an immutable, versioned file such as `enterprise-attack-19.1.json` or `ATLAS-2026.07.yaml`, never a floating one like `enterprise-attack.json` or `ATLAS-latest.yaml`. The sha256 recorded in `CHECKSUMS.json` is what lets you prove, a year later, that "we reported Q3 against ATT&CK 19.1" is a fact rather than a memory.

---

## 1. MITRE ATT&CK

The adversary behavior vocabulary for infrastructure: hosts, containers, cloud, identity, and network. What an attacker does to the plumbing. It has no vocabulary for prompt or model specific moves; that is ATLAS's job.

### Where it lives

| | |
|---|---|
| Human site | https://attack.mitre.org/ |
| Data repo | https://github.com/mitre-attack/attack-stix-data |
| Branch | `master` (main returns 404; do not use it) |
| Pin this URL | https://raw.githubusercontent.com/mitre-attack/attack-stix-data/master/enterprise-attack/enterprise-attack-19.1.json |
| Format and size | STIX 2.1 JSON bundle, ~51 MB, 25,843 objects |
| Also available | `mobile-attack-19.1.json` (~5.5 MB), `ics-attack-19.1.json` (~3.9 MB) |
| Discovery | `index.json` at the repo root lists every release in a `versions[]` catalog |
| License | MITRE ATT&CK terms of use |

**Watch out: Cloud and Containers are not separate files.** There is no `cloud-attack.json` or `containers-attack.json`. Only three top level bundles exist: enterprise, mobile, and ics. Cloud (IaaS), Containers, Identity, Network, and PRE are platforms inside the Enterprise bundle.

An even stronger pin is the git tag ref, whose contents can never move: `.../attack-stix-data/v19.1/enterprise-attack/enterprise-attack-19.1.json`. A TAXII 2.1 server exists at `attack-taxii.mitre.org` but serves the latest release only. It cannot pin a version, so use the versioned GitHub file.

### Pin it (automatic)

ATT&CK carries a `pinned_url` in the baseline, so the tool fetches it for you and records the hash:

```bash
# once per baseline, on an internet connected machine
python tools/pin_frameworks.py
#   ok enterprise-attack-19.1.json    9f2c1a8b7d3e4f60...
python tools/pin_frameworks.py --verify   # no network; recompute and check (CI, air gap)
```

The artifact lands at `frameworks/pinned/2026.07/enterprise-attack-19.1.json`, its hash is recorded in `frameworks/pinned/2026.07/CHECKSUMS.json`, and its version is declared in `frameworks/baseline-2026.07.yaml` under `frameworks.attack`.

Record the full version tuple in the baseline: `version: "19.1"` plus `spec_version: "3.3.0"`. Read `x_mitre_attack_spec_version` off the collection object, not by counting objects. If your git host objects to 51 MB, use Git LFS or an artifact store; the checksum is the part that must be committed, not necessarily the bytes.

### The source schema

One STIX 2.1 `bundle` with an `objects[]` array. The human readable ID you cite lives in `external_references[]` where `source_name == "mitre-attack"`.

```json
{ "type": "bundle", "objects": [
  { "type": "attack-pattern",
    "name": "Escape to Host",
    "x_mitre_version": "2.0",
    "revoked": false, "x_mitre_deprecated": false,
    "kill_chain_phases": [{ "phase_name": "privilege-escalation" }],
    "external_references": [
      { "source_name": "mitre-attack", "external_id": "T1611" } ]}
]}
```

| | |
|---|---|
| Object types | attack-pattern, x-mitre-tactic (15), course-of-action, x-mitre-data-component (109), x-mitre-detection-strategy (699), x-mitre-analytic (1,758), relationship (about 21,000) |
| ID shapes | `Txxxx`, sub-technique `Txxxx.yyy`, tactic `TAxxxx`, data component `DCxxxx`, mitigation `Mxxxx` |
| Retirement | `revoked` plus a revoked-by relationship (157), `x_mitre_deprecated` (289) |

**Watch out: two structural breaks live in this pin.** v18 retired data sources (DSxxxx) in favor of data components (DCxxxx), joined to techniques through new Detection Strategy (DETxxxx) and Analytic (ANxxxx) objects. v19 split Defense Evasion into Stealth (TA0005, renamed in place) and Defense Impairment (TA0112, new), so Enterprise now has 15 tactics. Any tactic level metric that spans that boundary is not comparable.

### Insert into Liszt's schema

ATT&CK IDs land in three places: on each step, in the scenario roll-up, and as data components on telemetry rows.

```yaml
attack_path:                     # map the steps first, 1 to 2 IDs each
  - step: 5
    layer: "Host / Cloud"
    text: "Pod to node root; metadata creds give cluster-admin"
    attack: [T1611, T1552.005]   # the sub-technique, not parent plus sub
framework_mapping:
  baseline: "2026.07"
  attack: [T1190, T1611, T1552.005]   # union of the step IDs, in chain order
  attack_tactics: [TA0001, TA0004]    # derived from the techniques
  mapping_confidence: editorial
telemetry:
  - step: 5
    data_components: [DC0057, DC0034]   # DCxxxx only, never DSxxxx
```

Schema definitions: `attackTechniqueId`, `attackTacticId`, `attackDataComponentId`. Count ceilings: 1 to 2 per step (max 3), 4 to 8 in the roll-up (max 10). Rules: most specific evidenced ID; sub or parent, never both; tactics derived, not authored.

### How it interacts

- **Validate.** Every Txxxx and DCxxxx must exist in the pinned bundle and be neither revoked nor deprecated. No ID is ever confirmed from memory.
- **Score.** Each technique's telemetry row carries DeTT&CT scores, which derive Have, Collectable, or Blind. See the DeTT&CT section.
- **Report.** The kill chain and stack layer report pages group by these IDs.
- **Migrate.** The only mostly automatable migration of the five. Walk the revoked-by relationships in the new bundle to remap replaced IDs, and freeze deprecated ones so historical scores survive. The April release is the annual re-baseline trigger.

### Documentation

- ATT&CK site: https://attack.mitre.org/
- Getting started and resources: https://attack.mitre.org/resources/
- Version history: https://attack.mitre.org/resources/versions/
- Release notes for each version: https://attack.mitre.org/resources/updates/
- STIX data repo and usage notes: https://github.com/mitre-attack/attack-stix-data
- mitreattack-python, MITRE's official parsing library: https://github.com/mitre-attack/mitreattack-python
- OASIS STIX 2.1 specification: https://docs.oasis-open.org/cti/stix/v2.1/os/stix-v2.1-os.html
- Terms of use: https://attack.mitre.org/resources/legal-and-branding/terms-of-use/

---

## 2. MITRE ATLAS

The adversary behavior vocabulary for AI systems: models, training data, RAG, agents, and agent tools. Where ATT&CK stops at the AI boundary, ATLAS begins. Where the two overlap, ATLAS marks its technique as adapted from ATT&CK.

### Where it lives

| | |
|---|---|
| Human site | https://atlas.mitre.org/ |
| Data repo | https://github.com/mitre-atlas/atlas-data |
| Branch | `main` (canonical) |
| Pin this URL | https://raw.githubusercontent.com/mitre-atlas/atlas-data/main/dist/v6/ATLAS-2026.07.yaml |
| Format and size | single self contained YAML, ~0.7 MB, the whole knowledge base |
| Release catalog | `dist/manifest.yaml` maps every content release to its files |
| License | Apache-2.0 |

**Watch out: three floating files to avoid.** `dist/v6/ATLAS-latest.yaml` and `dist/ATLAS-latest.yaml` are symlinks that move on every release. `dist/ATLAS.yaml` is deprecated and frozen; its own first line says so. Always pin the dated `dist/v6/ATLAS-<version>.yaml`.

**Watch out: the newest tag lags the newest content.** The tag `v2026.07` does not exist yet even though the 2026.07 content is already on `main`; the newest tag is `v2026.06`. For a fixed git ref, pin a commit SHA. Otherwise pin the dated filename on `main`; a dated file's contents are never rewritten, so it is effectively immutable.

### Pin it (automatic)

The same single command. ATLAS also carries a `pinned_url` in the baseline:

```bash
python tools/pin_frameworks.py   # fetches ATLAS-2026.07.yaml and records the sha256
```

The artifact lands at `frameworks/pinned/2026.07/ATLAS-2026.07.yaml`. Record both halves of the version tuple: content `2026.07` plus format `6.0.0`. They are decoupled as of the 2026.05 release.

ATLAS ships an `atlas-to-stix` tool that can emit a combined ATLAS and ATT&CK STIX bundle. That is co-packaging, not a crosswalk, and its `--include-attack` option pulls the latest ATT&CK, a floating dependency. Do not treat a combined bundle as pinned.

### The source schema

Eight ordered top level keys. Techniques carry the optional `attack-reference`, the single authoritative link into ATT&CK.

```yaml
format-version: 6.0.0
collection: { version: "2026.07" }
tactics: [ ... ]        # AML.TAxxxx (16)
techniques:             # AML.Txxxx and sub AML.Txxxx.yyy (178)
  - id: AML.T0105
    name: "Escape to Host"
    platforms: [Enterprise, Agentic AI]      # prefer Agentic AI on agent scenarios
    maturity: Realized                       # Realized, Demonstrated, or Feasible
    attack-reference: { id: T1611, url: ... }   # the only authoritative crosswalk
    uuid: ...
    modified-date: 2026-06-...               # the whole change tracking surface
mitigations: [ ... ]    # AML.Mxxxx; case-studies are AML.CSxxxx
```

Contents at the pin: 16 tactics, 178 techniques (101 parents, 77 subs), 37 mitigations, 68 case studies. Crosswalk reach: 37 of 178 techniques carry `attack-reference`; 141 are ATLAS only.

**Watch out: no deprecation mechanism.** ATLAS has no revoked or deprecated field. Change tracking is release notes plus each object's `modified-date` plus a stable `uuid`, and nothing else. That is why the migration below is manual.

### Insert into Liszt's schema

ATLAS IDs sit beside ATT&CK at the step level and in the roll-up. The `attack-reference` is what lets a pairing claim authoritative confidence.

```yaml
attack_path:
  - step: 5
    attack: [T1611]
    atlas:  [AML.T0105]   # carries attack-reference T1611, an authoritative pairing
framework_mapping:
  atlas: [AML.T0049, AML.T0105]
  mapping_confidence: editorial   # authoritative only if every pairing is an attack-reference
  mapping_notes: "AML.T0105 to T1611 is the ATLAS attack-reference; the rest is ours."
```

Fields: `framework_mapping.atlas[]` and `attack_path[].atlas`, technique or tactic IDs. Count ceilings: 1 to 2 per step (max 3), 3 to 6 in the roll-up (max 8).

### How it interacts

- **Validate.** Every AML ID is checked against the pinned YAML.
- **Author.** Use `platforms` to prefer Agentic AI techniques on agent scenarios, and sanity check `maturity` against the scenario's evidence tier. A seen-in-the-wild scenario mapped entirely to Feasible techniques is probably mis-scoped.
- **Migrate.** Manual by design. Diff consecutive releases on (id, modified-date), use `uuid` to catch an ID change under a stable object, and re-check `attack-reference` fields, since a technique can gain or lose one and flip a pairing between authoritative and editorial. Hold one ATLAS release for the year; do not chase the monthly cadence.

### Documentation

- ATLAS site: https://atlas.mitre.org/
- atlas-data repo and README: https://github.com/mitre-atlas/atlas-data
- Release manifest: https://raw.githubusercontent.com/mitre-atlas/atlas-data/main/dist/manifest.yaml
- Releases and release notes: https://github.com/mitre-atlas/atlas-data/releases

---

## 3. OWASP Top 10 for LLM Applications

A risk category vocabulary in the language a developer or AppSec reviewer already uses. Not techniques: no chain, no tactic, no step. It answers "what class of risk is this," and it lives at the scenario level only.

### Where it lives

| | |
|---|---|
| Human site | https://genai.owasp.org/llm-top-10/ |
| Repo | https://github.com/OWASP/www-project-top-10-for-large-language-model-applications |
| Official PDF | https://owasp.org/www-project-top-10-for-large-language-model-applications/assets/PDF/OWASP-Top-10-for-LLMs-v2025.pdf |
| Closest to data | per-entry markdown in `2_0_vulns/`, from `LLM01_PromptInjection.md` through `LLM10_UnboundedConsumption.md` |
| License | CC BY-SA 4.0 |

**Watch out: there is no official machine readable list.** No JSON, YAML, or CSV. The official artifacts are a versioned PDF, web pages, and per-entry markdown prose. Anything structured you need, you transcribe and maintain yourself, which the CC BY-SA 4.0 license permits with attribution and share-alike.

**Watch out: a 2026 edition is imminent.** A 2026 landing page has appeared but has not propagated to the repo or a stable PDF path. Stay pinned to 2025. Watch the repo for the real 2026 source before migrating: `changes.md`, and `2_0_vulns/` becoming a new entries directory.

### Pin it (PDF automatic, markdown manual)

The tool fetches the PDF, since the baseline carries its URL. Because the canonical form is human readable, pin the bytes:

```bash
python tools/pin_frameworks.py   # fetches OWASP-Top-10-for-LLMs-2025.pdf and records the sha256
# optional but recommended: also pin the markdown at a commit for a parseable source
curl -o LLM01.md https://raw.githubusercontent.com/OWASP/.../<SHA>/2_0_vulns/LLM01_PromptInjection.md
```

The artifact lands at `frameworks/pinned/2026.07/OWASP-Top-10-for-LLMs-2025.pdf`. Pin strategy: sha256 of the PDF, plus an optional maintained JSON transcription hashed in CI.

### The source schema

Each entry is a standalone markdown file with a consistent heading order, defined by the repo's `_template.md`. Key a parser off heading level and position, not exact titles, which vary slightly per entry.

```markdown
## LLM01:2025 Prompt Injection      <- the ID and title are the first heading
### Description
### Common Examples of Risk
### Prevention and Mitigation Strategies
### Example Attack Scenarios
### Reference Links
```

The ten, edition 2025: 01 Prompt Injection, 02 Sensitive Information Disclosure, 03 Supply Chain, 04 Data and Model Poisoning, 05 Improper Output Handling, 06 Excessive Agency, 07 System Prompt Leakage, 08 Vector and Embedding Weaknesses, 09 Misinformation, 10 Unbounded Consumption.

ID rule: edition scoped and reshuffled between editions. Always store `LLM03:2025`, never a bare `LLM03`.

### Insert into Liszt's schema

One field, scenario level only. OWASP IDs have no step level home, and the schema will not accept them on `attack_path[]`.

```yaml
framework_mapping:
  owasp_llm: [LLM03:2025, LLM06:2025]   # pattern ^LLM(0[1-9]|10):[0-9]{4}$
  mapping_confidence: editorial          # always; no authoritative OWASP to MITRE link exists
  mapping_notes: "LLM06 Excessive Agency is the core; LLM03 for the poisoned dependency."
```

Combined ceiling: `owasp_llm` plus `owasp_agentic` together, 2 to 5 (max 6).

### How it interacts

- **Validate.** The validator checks the ID shape by regex and membership against the baseline's `owasp_llm.ids` map. There is no upstream artifact to check against, so the baseline file is the vocabulary of record.
- **Report.** Feeds the risk category grouping, not the kill chain.
- **Migrate.** When a new edition ships, re-derive every mapping from the text, never by translating the number. OWASP publishes no complete old to new crosswalk, and the slots move between editions.

### Documentation

- OWASP GenAI Security Project: https://genai.owasp.org/
- LLM Top 10 hub: https://genai.owasp.org/llm-top-10/
- 2025 release page with download: https://genai.owasp.org/resource/owasp-top-10-for-llm-applications-2025/
- OWASP Foundation project page: https://owasp.org/www-project-top-10-for-large-language-model-applications/
- Source repo with per-entry markdown: https://github.com/OWASP/www-project-top-10-for-large-language-model-applications
- Change log: https://github.com/OWASP/www-project-top-10-for-large-language-model-applications/blob/main/changes.md

---

## 4. OWASP Top 10 for Agentic Applications

Risk categories specific to autonomy: tool invocation, delegated identity, persistent memory, agent to agent messaging, and action without a human in the loop. An agentic scenario usually carries this and the LLM list. Scenario level only.

### Where it lives

| | |
|---|---|
| Landing page | https://genai.owasp.org/resource/owasp-top-10-for-agentic-applications-for-2026/ |
| PDF download | https://genai.owasp.org/download/52117/ (the token in the full URL rotates; use the page's Download button) |
| Machine readable | none: no JSON, no YAML, and no GitHub repo |
| Initiative hub | https://genai.owasp.org/initiatives/agentic-security-initiative/ |
| License | CC BY-SA 4.0 |

**Watch out: do not confuse ASI with AST.** A different OWASP project, the Agentic Skills Top 10 (AST01 through AST10), does ship machine readable files, which makes it the easy thing to grab by mistake. You want ASI, the Agentic Security Initiative list for agentic applications. Also distinct from the earlier document "Agentic AI: Threats and Mitigations" v1.0 (2025), which has no stable ID scheme; cite that one as prose, never as IDs.

### Pin it (manual)

No automatic fetch. The baseline sets its URL to none and reports it as a manual step. Download by hand, drop it in place, then let the verify pass record the hash:

```bash
curl -L -o frameworks/pinned/2026.07/OWASP-Top-10-Agentic-2026.pdf \
     "https://genai.owasp.org/download/52117/"
python tools/pin_frameworks.py --verify   # records the sha256 of the hand placed PDF
```

The tool is explicit about this case: artifacts it cannot fetch are reported, not silently skipped. It prints the manual source and waits for the verify pass. A missing manual artifact means the pin is incomplete, and IDs are not yet verifiable offline.

### The source schema

PDF prose in OWASP's house style: description, common examples, example attack scenarios, prevention, references. The ten, edition 2026:

| ID | Title |
|---|---|
| ASI01 | Agent Goal Hijack |
| ASI02 | Tool Misuse and Exploitation |
| ASI03 | Identity and Privilege Abuse |
| ASI04 | Agentic Supply Chain Vulnerabilities |
| ASI05 | Unexpected Code Execution (RCE) |
| ASI06 | Memory and Context Poisoning |
| ASI07 | Insecure Inter-Agent Communication |
| ASI08 | Cascading Failures |
| ASI09 | Human-Agent Trust Exploitation |
| ASI10 | Rogue Agents |

### Insert into Liszt's schema

```yaml
framework_mapping:
  owasp_llm:     [LLM06:2025]                          # the model boundary risk, and
  owasp_agentic: [ASI03:2026, ASI05:2026, ASI10:2026]  # the action risk
  mapping_confidence: editorial
```

Field: `framework_mapping.owasp_agentic[]`, pattern `^ASI(0[1-9]|10):[0-9]{4}$`. The prefix is ASI, for Agentic Security Initiative; not AAI, and not AA. An agentic scenario usually carries both OWASP lists, because the model still sits under the agent.

### How it interacts

- **Validate.** Shape regex plus membership against the baseline's `owasp_agentic.ids` map. The list is PDF only, so the baseline is the vocabulary of record.
- **Warn.** The validator warns when a scenario is agentic but `owasp_agentic` is empty. Carrying only the LLM list understates an agent scenario.
- **Migrate.** Re-derive from the PDF text on any new edition, and re-hash the PDF periodically, since a living document can be republished at the same URL without a version bump.

### Documentation

- 2026 resource page with download: https://genai.owasp.org/resource/owasp-top-10-for-agentic-applications-for-2026/
- Agentic Security Initiative hub: https://genai.owasp.org/initiatives/agentic-security-initiative/
- OWASP GenAI Security Project: https://genai.owasp.org/

---

## 5. DeTT&CT

The odd one out: not a threat taxonomy. It defines no IDs. It annotates ATT&CK techniques with scores that answer one question: would we see it, and how good is the data? Liszt borrows its scales, visibility, detection, and quality, as the ruler behind every coverage number.

### Where it lives

| | |
|---|---|
| Repo | https://github.com/rabobank-cdc/DeTTECT |
| Wiki, with the scales | https://github.com/rabobank-cdc/DeTTECT/wiki |
| Current version | v2.2.0, released 2026-01-21; the newest tag, nothing later exists |
| Pin by tag | `git clone --branch v2.2.0 https://github.com/rabobank-cdc/DeTTECT.git` |
| Or the tarball | https://github.com/rabobank-cdc/DeTTECT/archive/refs/tags/v2.2.0.tar.gz |
| License | GPL-3.0 |

### Pin it (manual, git)

Vendored as a directory rather than a single file. The verify pass records its presence:

```bash
git clone --branch v2.2.0 https://github.com/rabobank-cdc/DeTTECT.git \
    frameworks/pinned/2026.07/DeTTECT-2.2.0
python tools/pin_frameworks.py --verify
```

**Watch out: a version offset worth writing down.** DeTT&CT v2.2.0 targets ATT&CK v18, while Liszt pins ATT&CK v19.1. That is fine here, because Liszt borrows only the scales, not DeTT&CT's ATT&CK coupled tooling. But record the DeTT&CT version and the ATT&CK version it ran against in every snapshot. A mismatch here is the most common source of an unexplained score shift.

### The source schema: the scales Liszt adopts

Liszt does not run DeTT&CT's YAML pipeline. It adopts the scoring model verbatim into `telemetry[].dettect`. These three scales are the whole contract:

| Scale | Range | Values |
|---|---|---|
| visibility | 0 to 4 | 0 None, 1 Minimal, 2 Medium, 3 Good, 4 Excellent |
| detection | -1 to 5 | -1 None, 0 Forensics or context only, 1 Basic, 2 Fair, 3 Good, 4 Very good, 5 Excellent |
| quality | 0 to 5 each | device_completeness, data_field_completeness, timeliness, consistency, retention |

DeTT&CT's native tooling (YAML admin files, the DeTT&CT Editor web UI, ATT&CK Navigator layers) is not needed by Liszt. It is fully local once ATT&CK STIX is supplied, which gives it the best air gap story of the five.

### Insert into Liszt's schema

No `framework_mapping` array, because there are no IDs. The scores live on each telemetry row, and `coverage` is derived, never authored:

```yaml
telemetry:
  - step: 5
    signal: "container escape to node"
    dettect:
      visibility: 4
      detection:  3
      quality: { device_completeness: 4, data_field_completeness: 4,
                 timeliness: 4, consistency: 4, retention: 3 }
    coverage: Have   # a cache of derive_coverage(); the validator recomputes it and errors on mismatch
```

### How it interacts: the coverage engine

This is where DeTT&CT scores become every report. One rule, implemented once in `validate.py::derive_coverage()` and imported by `coverage.py`:

```python
def derive_coverage(dettect):
    vis, det = dettect["visibility"], dettect["detection"]
    if vis == 0:
        return "Blind"                                # nothing produces the signal
    return "Have" if det >= 1 else "Collectable"      # wired to detection, or logged only
```

| Tag | Condition | Meaning |
|---|---|---|
| Blind | visibility 0, any detection value | nothing produces the signal |
| Collectable | visibility 1 or more, detection 0 or less | logged for forensics, nothing alerts (the cheapest Have) |
| Have | visibility 1 or more, detection 1 or more | emitted and wired to detection |

- **Required to count.** A scenario needs every row scored to enter maturity reporting. An unscored row is None, not Blind, and it is an error on a published record.
- **Quality qualifies, never reclassifies.** The five quality dimensions describe a Have; they never change the tag.
- **Detection claims trace to a use case.** The validator warns when a row claims detection maturity and no use case covers that step. A detection claim needs a receiver.

### Documentation

- DeTT&CT repo: https://github.com/rabobank-cdc/DeTTECT
- Wiki, methodology and scoring: https://github.com/rabobank-cdc/DeTTECT/wiki
- Releases: https://github.com/rabobank-cdc/DeTTECT/releases

---

## The runbook

### One pass, per baseline

```bash
# 1. on an internet connected machine, fetch the three automatic artifacts
python tools/pin_frameworks.py
#   ok: enterprise-attack-19.1.json, ATLAS-2026.07.yaml, and the LLM PDF

# 2. place the two manual artifacts by hand
curl -L -o frameworks/pinned/2026.07/OWASP-Top-10-Agentic-2026.pdf \
     "https://genai.owasp.org/download/52117/"
git clone --branch v2.2.0 https://github.com/rabobank-cdc/DeTTECT.git \
     frameworks/pinned/2026.07/DeTTECT-2.2.0

# 3. record and verify every hash (no network), then commit the pin
python tools/pin_frameworks.py --verify      # same as ./liszt verify-pin
git add frameworks/pinned/
git commit -m "pin frameworks 2026.07"

# 4. from here on, IDs are verifiable offline and auditable
./liszt validate      # checks every ID against the pin
./liszt serve         # the viewer
```

### The pinned tree

```text
frameworks/
  baseline-2026.07.yaml            # version tuple, pinned URLs
  pinned/2026.07/
    CHECKSUMS.json                 # the audit anchor; commit it
    enterprise-attack-19.1.json    # ~51 MB, automatic
    ATLAS-2026.07.yaml             # ~0.7 MB, automatic
    OWASP-Top-10-for-LLMs-2025.pdf # automatic
    OWASP-Top-10-Agentic-2026.pdf  # by hand
    DeTTECT-2.2.0/                 # git clone
```

### Where each framework lands

| Framework | Target fields |
|---|---|
| ATT&CK | `framework_mapping.attack[]`, `attack_path[].attack`, `telemetry[].data_components` |
| ATLAS | `framework_mapping.atlas[]`, `attack_path[].atlas` |
| OWASP LLM | `framework_mapping.owasp_llm[]` |
| OWASP Agentic | `framework_mapping.owasp_agentic[]` |
| DeTT&CT | `telemetry[].dettect` (visibility, detection, quality) |

### Day one checklist

- [ ] Fetch the three automatic artifacts with `pin_frameworks.py`
- [ ] Hand place the OWASP Agentic PDF and clone DeTT&CT at v2.2.0
- [ ] The verify pass is clean, every hash matches; commit `CHECKSUMS.json`
- [ ] Pinned filenames are versioned, never floating pointers
- [ ] The baseline records the full version tuple, including ATLAS format 6.0.0 and the ATT&CK version DeTT&CT targets
- [ ] `./liszt validate` returns zero errors

### When a framework releases (migration)

- [ ] Cut a new `baseline-YYYY.MM.yaml`; mark the old one superseded, never delete it
- [ ] ATT&CK, mostly automatable: walk `revoked-by`, freeze deprecated IDs
- [ ] ATLAS, manual: diff on (id, modified-date), re-check `attack-reference`
- [ ] Both OWASP lists, manual: re-derive from text, do not translate numbers
- [ ] Dual report one full cycle against both pins before switching
- [ ] Flag tactic level metrics that span the v19 Defense Evasion split as not comparable
