# 11. The schema behind Liszt

**Audience:** the developers building the production tool.
**Authority:** `schema/scenario.schema.json` and `schema/use-case.schema.json` define the authored records, `tools/validate.py` enforces the rules, and the documented contracts live in `docs/`. If this document disagrees with any of them, they win and this document is wrong; file it.

Read from the repo in August 2026, at baseline 2026.07 and scenario schema_version 1. Companion artifacts: the [HTML wireframe](wireframes/liszt-schema-wireframe.html), the [Word version](wireframes/Liszt-Schema-Wireframes.docx), and the standalone [crow's foot chart](wireframes/liszt-schema-er-diagram.svg).

---

## Four families of record

Every file in the system belongs to one of four families, and the family tells you the rules it lives under.

| Family | Rules | Files |
|---|---|---|
| **Authored records** | Human written, schema validated, human reviewed | `scenarios/NNN-slug.yaml`, `use-cases/UC-NNN-slug.yaml`, `incidents/slug.yaml`, `coverage/org/NNN.yaml` |
| **Pinned vocabulary** | Immutable artifacts with checksums | `frameworks/baseline-YYYY.MM.yaml`, `frameworks/pinned/YYYY.MM/` + `CHECKSUMS.json` |
| **Generated payloads** | Built from the records, never hand edited, consumed by contract | `liszt-data.json`, metric snapshots |
| **Working and roadmap** | Move data between people and records; production additions | `liszt-session-DATE.json`, `patterns/AP-NNN.yaml` (design), run records (MVP+5) |

The flow over them: **author** a record, **validate** it (`./liszt validate` checks structure, referential integrity, framework IDs against the pin, and the derived coverage), **review** it (a second person signs `reviewed_by`), **generate** the projections (`build_viewer.py`), and **report** (`coverage.py` emits an immutable snapshot per org).

---

## The whole model on one page

Solid lines are structural references. Dashed lines are generated or working flows, and the roadmap records.

![Liszt data model, crow's foot entity chart](wireframes/liszt-schema-er-diagram.svg)

The same model as Mermaid source, for quick edits and for renderers without the SVG:

```mermaid
erDiagram
    SCENARIO {
        string id PK "NNN, immutable, never reused"
        string status "draft | in-review | published | retired"
        string baseline FK "framework_mapping.baseline"
        string classification "layer, evidence, priority, mode"
        string provenance "authored_by, reviewed_by, sources[]"
    }
    ATTACK_PATH_STEP {
        int step PK "1..6, 3..6 per scenario"
        string layer "free text reading aid"
        string text "25..125 chars, one line"
        string attack "Txxxx IDs, checked against pin"
        string atlas "AML.Txxxx IDs"
    }
    EVIDENCE_ROW {
        int step FK "matches an attack path step"
        string kind "attack-step | control"
        string signal "what is emitted"
        string source "the exact system, named"
        string data_components "DCxxxx"
        string coverage "DERIVED, cached"
        string owner_evidence_backlog "gap owner, proof, ticket"
    }
    DETTECT_SCORE {
        int visibility "0..4"
        int detection "-1..5"
        string quality "five dimensions, 0..5 each"
    }
    USE_CASE {
        string id PK "UC-NNN, immutable"
        string status "proposed | built | tuned | retired"
        string trigger "one signal, one source"
        string outcome "kind, autonomy, consumer, action"
        string promotion "required above notify"
    }
    COVERS {
        string scenario FK "NNN"
        string steps "1..*, validated"
    }
    INCIDENT {
        string slug PK
        date date
        string what_happened
        string references "tier 0|1|2, url"
    }
    FRAMEWORK_BASELINE {
        string baseline PK "YYYY.MM"
        string status "current | superseded"
        string owner "a named individual"
    }
    PINNED_ARTIFACT {
        string key PK "per baseline"
        string filename "versioned, immutable"
        string sha256
    }
    COVERAGE_OVERLAY {
        string org PK
        string scenario FK "NNN"
        string assessed_by
    }
    OVERLAY_ROW {
        int step FK "1..6"
        string inherit_or_scores
        string coverage "DERIVED"
    }
    SESSION_FILE {
        string edits "per scenario and step"
        string new_scenarios "proposals, IMP-n"
    }
    VIEWER_DATA {
        int data_version "1, pin on this"
        string view "org, includes_drafts"
    }
    SNAPSHOT {
        string snapshot_id PK
        string org "exactly one"
        string frameworks "tuple + sha256s"
    }
    ATTACK_PATTERN {
        string id "AP-NNN, production design"
        string cited_by "computed"
        string defended_by "computed"
    }
    RUN_RECORD {
        string spec "OpenSpec, from the record"
        string result "measured, MVP+5"
    }

    SCENARIO ||--|{ ATTACK_PATH_STEP : "contains 3..6"
    SCENARIO ||--|{ EVIDENCE_ROW : "contains 3..8"
    EVIDENCE_ROW ||--|| ATTACK_PATH_STEP : "answers"
    EVIDENCE_ROW ||--o| DETTECT_SCORE : "scored by"
    SCENARIO ||--o{ HARDENING_ITEM : "hardening"
    HARDENING_ITEM }o--|{ ATTACK_PATH_STEP : "breaks"
    SCENARIO }o--o{ INCIDENT : "cites, both directions"
    SCENARIO }o--|| FRAMEWORK_BASELINE : "speaks"
    FRAMEWORK_BASELINE ||--|{ PINNED_ARTIFACT : "vendors 5"
    USE_CASE ||--|{ COVERS : "has"
    COVERS }o--|| SCENARIO : "names scenario + steps"
    COVERAGE_OVERLAY }o--|| SCENARIO : "per org override"
    COVERAGE_OVERLAY ||--|{ OVERLAY_ROW : "rows"
    OVERLAY_ROW }o..o| EVIDENCE_ROW : "overrides 0..1 per step"
    SESSION_FILE }o..o{ EVIDENCE_ROW : "proposes edits"
    SESSION_FILE }o..o{ SCENARIO : "proposes drafts"
    VIEWER_DATA }o..o{ SCENARIO : "projects"
    SNAPSHOT }o..|| FRAMEWORK_BASELINE : "records the tuple"
    SNAPSHOT }o..o{ SCENARIO : "measures published"
    ATTACK_PATTERN }o..o{ ATTACK_PATH_STEP : "cited_by, roadmap"
    ATTACK_PATTERN }o..o{ USE_CASE : "defended_by, roadmap"
    RUN_RECORD }o..|| SCENARIO : "spec from, roadmap"
```

HARDENING_ITEM carries `action`, `breaks_step[] 1..*`, `leverage`, `owner`, and `backlog_ref`.

---

## 1. The scenario record

`scenarios/NNN-slug.yaml`. The system of record: one attack chain, described once, with the evidence map that says whether we would see it. Slides, coverage metrics, and tabletop material are all generated from this record; PowerPoint is a build artifact.

### Identity and lifecycle

| Field | Rules |
|---|---|
| `id` | "NNN" zero padded, quoted (or YAML strips the zeros). Immutable once published, never reused, even after retirement |
| `slug`, `title`, `one_liner` | the one_liner must read for a non specialist executive; 40 to 420 chars |
| `status` | `draft`, `in-review`, `published`, `retired` |
| `retired { }` | date, reason, superseded_by. Retired records stay in the repo forever |
| `schema_version` | 1. Bumped only on a breaking change, with `schema/CHANGELOG.md` |

### Classification and framework mapping

| Field | Rules |
|---|---|
| `classification` | primary_layer_component, ai_infrastructure_layer (L0..L4), evidence (`seen-in-the-wild`, `seen-in-research`, `doomsday`), priority (`NOW`, `NEAR-TERM`, `BACKLOG`) plus rationale, mode (`attack` or `failure`) |
| `framework_mapping` | `baseline` "YYYY.MM" points at the pinned vocabulary; never mix baselines in one record. `attack[]`, `attack_tactics[]`, `atlas[]`, `owasp_llm[]`, `owasp_agentic[]`, `mapping_confidence` (`authoritative` or `editorial`), `mapping_notes` |

Watch out: OWASP IDs live at the scenario level only. The attack_path steps accept `attack` and `atlas` arrays and nothing else; the schema enforces it.

### The chain: attack_path[]

Three to six ordered steps. Six is a hard ceiling: a chain that needs more is two scenarios in a trenchcoat, split it.

| Field | Rules |
|---|---|
| `step` | 1..6 |
| `layer` | free text reading aid, for example "Host / Cloud"; the controlled field is `classification.ai_infrastructure_layer` |
| `text` | 25..125 chars, one line; the renderer will not wrap past that |
| `attack[]`, `atlas[]` | framework IDs for this step, checked against the pin; 1 to 2 each, max 3 |
| `control_held` | bool. What held is as valuable as what failed, and it is the most commonly omitted field |

### The evidence map: telemetry[]

Three to eight rows. Every attack path step must have a matching attack-step row; extra control rows record verification signals. This is the deliverable: the answer to "would we see it." The program's display word is evidence; the YAML and JSON key stays `telemetry`, because renaming a key is a breaking change for every record, overlay, session file, and consumer.

| Field | Rules |
|---|---|
| `step`, `kind` | row number; `attack-step` or `control` |
| `signal`, `emitted_at` | what is emitted, and which layer or control emits it |
| `source` | the exact system by name: product, index, table, topic. Required in practice for Have and Collectable |
| `data_components[]` | DCxxxx only; v18 retired DSxxxx |
| `dettect { }` | visibility 0..4, detection -1..5, quality x5 (the DeTT&CT scales) |
| `coverage` | `Have`, `Collectable`, `Blind`. DERIVED from the scores and cached; the validator recomputes it and errors on mismatch |
| `owner`, `evidence`, `backlog_ref` | gap owner; proof behind a Have; the ticket that closes the loop |

The one rule, `tools/validate.py::derive_coverage()`:

```python
if visibility == 0:      # Blind        nothing produces the signal
elif detection >= 1:     # Have         emitted and wired to detection
else:                    # Collectable  logged only; the cheapest Have
```

Watch out: an unscored row is None, not Blind. Zero and unknown are different claims, and the program exists to keep them apart. A published record with an unscored attack-step row is a validator error.

### Hardening, provenance, and the trimmed record

| Field | Rules |
|---|---|
| `hardening[]` | action, `breaks_step[]` 1..* (an item that breaks no step is generic best practice and does not belong), leverage, owner, backlog_ref |
| `provenance` | authored_by, reviewed_by (must differ; required before publish), created, last_updated, review_date, `sources[] { tier 0|1|2, url }` |
| `commentary`, `scaled_up` | the three paragraph analysis block; scaled_up is always hypothetical |
| `incidents[]` | slugs of records in `incidents/`; referential integrity enforced |

```yaml
# scenarios/021-agent-sandbox-escape-to-autonomous-intrusion.yaml, trimmed
schema_version: 1
id: '021'
title: Agent sandbox escape → autonomous intrusion
status: published
classification: { priority: NOW, evidence: seen-in-the-wild }
framework_mapping: { baseline: '2026.07', attack: [T1190, T1611], mapping_confidence: editorial }
attack_path:
  - { step: 2, layer: Host / net, text: "A zero-day in the package proxy ...",
      attack: [T1190], atlas: [AML.T0049] }
telemetry:
  - { step: 2, signal: "egress from the agent sandbox to a new external host",
      source: "NetFlow + egress proxy, index=net_egress",
      dettect: { visibility: 3, detection: 2, quality: { } },
      coverage: Have, evidence: NET-EGRESS-ANOM-07 }
provenance: { authored_by: x, reviewed_by: y, sources: [{ tier: '0', url: z }] }
```

**References.** Points at: the baseline (`framework_mapping.baseline`), incidents (`incidents[]` slugs), and the pinned framework IDs on every step and row. Pointed at by: use cases (`covers[]`), coverage overlays (per org), session files (proposed edits), and the generated payloads.

---

## 2. The use case record

`use-cases/UC-NNN-slug.yaml`. The scenario says what evidence should exist and whether it does. The use case says what gets done with it. A separate record because one use case can serve several scenarios, and copies are how libraries rot. Its lifecycle (`proposed`, `built`, `tuned`, `retired`) moves on an engineering clock, not a review clock.

| Field | Rules |
|---|---|
| `covers[]` | `{ scenario: "NNN", steps: [..] }`. The join to the library; the validator checks both ends. List only steps whose rows this use case actually reads |
| `trigger` | `{ signal, source }`, exactly one. Two possible triggers is two use cases |
| `composes[]` | `{ signal, source, role }` where role is `enrichment`, `corroboration`, or `scoping`. May be empty, which records the question as answered, not skipped |
| `pipeline` | `strategy` (`collect-centrally`, `instrument-at-source`, `evaluate-at-platform`), `destination`, `owner` (the builder, never the consumer) |
| `outcome` | `kind` (`alert`, `report`, `trend`, `dashboard`, `enrichment`, `response`), `autonomy` (`notify`, `assisted`, `autonomous`), `consumer`, `action` |
| `promotion` | required whenever autonomy is above notify; the validator enforces it |
| `limits` | the stated blind side. A use case with no stated limit will be trusted past its range |

The promotion block is the record that gets pulled the first time an automated action misbehaves: `from` (the level it ran at while evidence was collected; one rung at a time), `evidence` (true_positive_rate + window + volume), `action_consistency` (the share of true positives that received the same operator response; accuracy says the detection is real, consistency says the response is automatable), `blast_radius`, `reversible`, `approved_by`, `approved`, `review`, and `disable`. An automation nobody can stop was never safe to start.

**References.** Points at scenario steps through `covers[]`. The validator warns when a scenario row claims detection maturity and no use case covers that step: a detection claim needs a receiver.

---

## 3. The incident source record

`incidents/slug.yaml`. A real world event the library cites, so a claim of seen-in-the-wild traces to something a reviewer can check.

```yaml
# incidents/anthropic-evaluation-models-reaching-outside-systems-2026.yaml
slug: anthropic-evaluation-models-reaching-outside-systems-2026
title: Evaluation agents reaching outside systems
date: 2026-07-30
what_happened: >
  A second lab reported models escaping containment during cyber testing
  and touching three outside organizations.
source: Anthropic disclosure, 2026
scenarios: ["021"]
references:
  - { tier: "2", title: "Press reporting of the disclosure", url: https://... }
```

Tier scale: 0 first party or primary technical source, 1 reputable secondary, 2 press. Maturity gate M7 wants at least one tier 0 source behind a published scenario, waived for doomsday records. Both directions of the join are recorded (`incident.scenarios[]` and `scenario.incidents[]`), and the validator enforces that both resolve.

---

## 4. The framework baseline and the pinned artifacts

`frameworks/baseline-YYYY.MM.yaml` plus `frameworks/pinned/YYYY.MM/` with `CHECKSUMS.json`. Every framework ID in every record is expressed in exactly one baseline's terms, and the baseline names the immutable artifacts, with checksums, that make each ID verifiable offline. Without this, a coverage drop and MITRE renaming a tactic are indistinguishable.

| Field | Rules |
|---|---|
| `baseline`, `status`, `owner` | "YYYY.MM"; `current` or `superseded`, never deleted; a named individual, not a team |
| `frameworks { }` | one block per framework: version tuple, release date, pinned artifact and URL, id stability notes, breaking changes since the prior baseline |
| `crosswalks` | the honesty section: the ATLAS attack-reference is partial and one way; OWASP to MITRE has nothing authoritative; everything else is editorial |
| `CHECKSUMS.json` | per artifact: filename, version, url, sha256, bytes. Written by `tools/pin_frameworks.py`; `--verify` re-checks with no network |

The full intake mechanics for each framework, with URLs, formats, and pin commands, are in the companion document: [10. Framework intake](10-framework-intake.md).

---

## 5. The coverage overlay

`coverage/org/NNN.yaml`. The scenario library is org independent; coverage is a property of one estate. An overlay overrides individual evidence rows for one org without touching the shared record. This split is what makes adoption cheap: a team can take the whole library without ever publishing where it is blind.

```yaml
# coverage/_example-org/021.yaml, trimmed
scenario: '021'
org: _example-org
assessed_by: <name>
assessed: '2026-07-31'
telemetry:
  - { step: 1, inherit: true }        # we agree with the reference
  - step: 2                           # different egress stack here
    dettect: { visibility: 4, detection: 0, quality: { } }
    coverage: Collectable             # derived, recomputed by the validator
    owner: Platform Networking
    backlog_ref: SEC-882
```

- Row level, not record level: a row resolves to the overlay if present, otherwise to the reference assessment.
- `inherit: true` means not assessed by this org. The row drops out of that org's scored set.
- The derivation rule is not org configurable. That is what makes two orgs' numbers mean the same thing.
- An overlay may only touch the org scoped fields. One that redefines the attack path is a fork; split the scenario in the library instead.

---

## 6. The session file

`liszt-session-DATE.json`. The capture loop: the viewer records scores, sources, owners, and tickets while the people who own those systems are in the room, exports one JSON file, and never writes a record itself.

| Carries | Detail |
|---|---|
| Row edits | per scenario and step: `dettect`, `coverage`, `source`, `owner`, `evidence`, `backlog_ref`, `notes` (exactly the org scoped fields) |
| `new_scenarios[]` | proposals captured in the room or imported through the intake journeys (IMP-n drafts with incident, research, or hypothesis origin). Each becomes a draft record via `new_scenario.py`, so a proposed record and a keyboard started one come out identical |
| Apply paths | `python3 tools/apply_session.py session.json` writes the scenario records; `--org NAME` writes `coverage/NAME/` overlays instead |

Nothing is committed automatically. The loop ends with `git diff`, `./liszt validate`, and a human commit.

---

## 7. The generated payloads

Two build artifacts with documented contracts. Never hand edited, never a source of truth.

### liszt-data.json, the viewer data contract

```jsonc
{
  "data_version": 1,               // the only compatibility guarantee; pin on this
  "view": { "org": "..", "includes_drafts": false },   // surface both in any UI
  "baseline": { },                 // the versions every ID speaks
  "library": { "records": 1, "mean_have": 0.5, "exposed": 1 },
  "scenarios": [ ],                // each record + counts + metrics + use_case_ids
  "use_cases": [ ], "incidents": { },
  "frameworks": { "attack": { "T1190": ["021"] } }     // reverse index
}
```

Consume this, not the YAML: it already carries the computed metrics, so no consumer reimplements the derivation and disagrees with the program. Within a data_version, fields are added, never removed or repurposed; a consumer should refuse to render a version it does not know.

### The metric snapshot

```yaml
snapshot_id: 2026-08-01-acme-2026.07
generated_by: { tool: tools/coverage.py, repo_commit: <git sha> }
org: acme                          # exactly one org per snapshot
baseline: '2026.07'
frameworks: { }                    # the full version tuple, read from the PINNED artifacts
library: { by_status: { }, retired_this_period: [], ids_rescored_this_period: [] }
metrics:
  coverage: { have: 0.500, collectable: 0.333, blind: 0.167, completeness: 1.000 }
  exposure: { now_exposed: 1, orphaned_steps: 0 }
  maturity: { mean: 1.000 }
non_comparable_with: [ ]           # populated at every baseline migration
```

Immutable and kept forever; a correction is a new snapshot with a supersedes key. `ids_rescored_this_period` is the anti drift field: a coverage change with no ticket behind it is a rescore, not an improvement. At a baseline migration, emit two snapshots, one per pin, for one full cycle.

---

## 8. The roadmap records

Design, not shipped code. Both follow the same rules as the rest of the library: plain text, schema validated, reviewed.

**The attack pattern record** (`patterns/AP-NNN.yaml`, with the production build): the reusable move between the framework catalogs and the scenarios. One technique, described once in our stack's terms, with generic telltales, cited by every scenario that contains it and defended once for all of them. `cited_by` and `defended_by` are computed reverse indexes, so a stale one cannot exist. STIX 2.1 defines an object type literally named attack-pattern; this record serializes straight into it.

**The run record** (MVP+5, month 13): an OpenSpec test specification generated from a scenario record, a testing agent built against it, a sandboxed run, and a measured result that feeds back into the evidence rows, so a coverage claim can point at a run that demonstrated it.

---

## The rules that hold the model together

- **Derived is never authored.** `coverage` on any row is a cache of `derive_coverage()`; the validator recomputes and errors on mismatch. The same rule applies in overlays.
- **Unknown is not zero.** An unscored row is None, excluded from the population, never counted as Blind.
- **IDs are immutable and never reused**, even after retirement. Splits retire the old record with `superseded_by`.
- **Retired records stay forever.** Excluded from current metrics, preserved for history.
- **reviewed_by must differ from authored_by** before a record can publish.
- **additionalProperties is false everywhere.** An unknown field is an error, not an extension point.
- **Every framework ID resolves against the pin.** Nothing is confirmed from memory.
- **Quote the numeric ids.** '021' stays '021'; unquoted YAML strips the zeros.

### Lifecycles

| Record | Lifecycle |
|---|---|
| Scenario | draft, in-review, published, retired |
| Use case | proposed, built, tuned, retired (an engineering clock, not a review clock) |
| Autonomy | notify, assisted, autonomous (earned with measured evidence, one rung at a time) |
| Baseline | current, superseded (annual, with one dual reported cycle) |

### The toolchain over the records

| Tool | Job |
|---|---|
| `tools/validate.py` | structure, referential integrity, pin checks, derivation; owns `derive_coverage()` |
| `tools/coverage.py` | the only supported way to produce the numbers; emits snapshots |
| `tools/build_viewer.py` | projects the library into `liszt-viewer.html` + `liszt-data.json` |
| `tools/apply_session.py` | session file to records, or to overlays with `--org` |
| `tools/pin_frameworks.py` | vendors the framework artifacts and records the checksums |
| `tools/new_scenario.py` | the one place a record scaffold comes from |

---

## Standards the schemas lean on

- JSON Schema, draft 2020-12, the dialect both record schemas declare: https://json-schema.org/specification
- YAML specification, the authoring format for every record: https://yaml.org/spec/
- DeTT&CT wiki, the scoring scales adopted in `telemetry[].dettect`: https://github.com/rabobank-cdc/DeTTECT/wiki
- OASIS STIX 2.1, the serialization target for the pattern record: https://docs.oasis-open.org/cti/stix/v2.1/os/stix-v2.1-os.html
