# Wireframe artifacts

Companion artifacts for two of the numbered docs. The markdown docs one level up are the
text of record; these are the same content in richer forms.

| File | Belongs to | What it is |
|---|---|---|
| `liszt-framework-intake.html` | [10. Framework intake](../10-framework-intake.md) | Visual wireframe: one flow per framework (get it, pin it, source schema, insert, interact), with verified URLs and pin commands |
| `Liszt-Framework-Intake.docx` | [10. Framework intake](../10-framework-intake.md) | The same content as a Word reference |
| `liszt-schema-wireframe.html` | [11. The schema behind Liszt](../11-schema-wireframes.md) | Visual wireframe: one panel per record type, with the entity chart embedded |
| `Liszt-Schema-Wireframes.docx` | [11. The schema behind Liszt](../11-schema-wireframes.md) | The same content as a Word reference, chart on a landscape page |
| `liszt-schema-er-diagram.svg` | [11. The schema behind Liszt](../11-schema-wireframes.md) | The data model as a crow's foot entity chart |

Facts inside were verified in August 2026 against baseline 2026.07 and the repo at
scenario schema_version 1. When a baseline migrates or a schema version bumps, these
artifacts are part of what the migration checklist reviews.

The HTML files are self contained: no network requests, no build step, open them in any
browser.
